package com.mycompany.supermarket;

import java.io.Serializable;
import java.util.Scanner;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Employee implements Serializable {

    private int id;
    private String name;
    private int age;
    private String position;
    private Item it;
    Scanner input = new Scanner(System.in);

    public Employee() {
        id = 0;
        name = " ";
        age = 0;
        position = " ";
        it = null;
    }

    public Employee(int id, String name, int age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }

    public Employee(int id, String name, int age, String position) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.position = position;

    }

    public Employee(int id, String name, int age, String position, Item i) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.position = position;
        this.it = i;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getPosition() {
        return position;
    }

    public Item getI() {
        return it;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public void setI(Item i) {
        this.it = i;
    }

    public void addItem(int id, String name, double price, int quantity, ArrayList<Item> Item) {
        Item t = new Item(id, name, price, quantity);
        Item.add(t);
    }

    public Item removeItem(int id, ArrayList<Item> Item) {
        for (int i = 0; i < Item.size(); i++) {
            Item x = Item.get(i);
            if (x.getId() == id) {
                JOptionPane.showMessageDialog(null, "Item " + x.getName() + " has been succesfully removed");
                return Item.remove(i);
            }
        }

        return null;
    }

    public void updateItem(ArrayList<Item> Item, int choice, int ident, double p) {
        int x;
            switch (choice) {
                case 1:
                    for (int i = 0; i < Item.size(); i++) {
                        x = Item.get(i).getId();
                        if (ident == x) {
                            Item.get(i).setPrice(p);
                                                   }
                    }
                    break;
                    
                case 2:
                    for (int i = 0; i < Item.size(); i++) {
                        x = Item.get(i).getId();
                        if (ident == x) {
                            Item.get(i).setQuantity((int)p);
                        }
                    }
                    break;
            }
        }


    public double generateReport(ArrayList<Bill> Bill) {
        double cost = 0;
        for (int i = 0; i < Bill.size(); i++) {
            cost += Bill.get(i).getnPrice();
        }
        return cost;
    }

    @Override
    public String toString() {
        return "Employee{ " + "id = " + id + ", name = " + name + ", age = " + age + ", position = " + position + '}';
    }
}
