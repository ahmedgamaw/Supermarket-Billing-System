/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.supermarket;

import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class SameInputException extends Exception{
    SameInputException(){
                JOptionPane.showMessageDialog(null,"New input same as old input!" ,"Error", JOptionPane.ERROR_MESSAGE);

    }
}
