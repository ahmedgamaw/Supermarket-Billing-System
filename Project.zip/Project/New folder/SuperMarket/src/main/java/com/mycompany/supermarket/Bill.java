package com.mycompany.supermarket;

import java.io.Serializable;

public class Bill implements Serializable {
     private int amount;
     private String itemN;
     private double nPrice;
     private int orderNum;
     static protected int oNum = 0;

    public Bill() {
        amount = 0;
        itemN = " ";
        nPrice = 0.0;
        orderNum = 0;
        oNum++;
    }

    public Bill(int amount, String itemN, double nPrice, int orderNum) {
        this.amount = amount;
        this.itemN = itemN;
        this.nPrice = nPrice;
        this.orderNum = orderNum;
        oNum++;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getItemN() {
        return itemN;
    }

    public void setItemN(String itemN) {
        this.itemN = itemN;
    }

    public double getnPrice() {
        return nPrice;
    }

    public void setnPrice(double nPrice) {
        this.nPrice = nPrice;
    }

    public int getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(int orderNum) {
        this.orderNum = orderNum;
    }

    public static int getoNum() {
        return oNum;
    }

    @Override
    public String toString() {
        return "Order{" + "amount = " + amount + ", itemN = " + itemN + ", nPrice = " + nPrice + ", orderNum = " + orderNum + '}';
    }

     
}
