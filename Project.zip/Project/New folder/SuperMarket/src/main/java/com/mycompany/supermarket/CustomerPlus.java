package com.mycompany.supermarket;

import java.io.Serializable;
import java.util.ArrayList;

public class CustomerPlus extends Customer implements Serializable {

    protected String subscription;

    public CustomerPlus() {
        subscription = " ";
    }

    public CustomerPlus(String subscription, String Fname, String Lname, String Email, String password, String username) {
        super(Fname, Lname, Email, password, username);
        this.subscription = subscription;
    }

    public String getSubscription() {
        return subscription;
    }

    public void setSubscription(String subscription) {
        this.subscription = subscription;
    }

    @Override
    public double viewBill(ArrayList<Bill> Bill, int orderNo) {
        double cost = 0;
        for (int i = 0; i < Bill.size(); i++) {
            if (orderNo == Bill.get(i).getOrderNum()) {
                cost += Bill.get(i).getnPrice();
            }
        }
        if (subscription.equals("Elite")) {
            return cost * 0.9;
        } else if (subscription.equals("Premium")) {
            return cost * 0.95;
        } else if (subscription.equals("Gold")) {
            return cost * 0.98;
        } else {
            return cost;
        }
    }

    @Override
    public String toString() {
        return "CustomerPlus{" + "subscription = " + subscription + '}';
    }

}
