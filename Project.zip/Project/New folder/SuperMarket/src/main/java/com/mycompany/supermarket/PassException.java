/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.supermarket;

import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class PassException extends Exception {

    public PassException() {
        JOptionPane.showMessageDialog(null, "Invalid input, The password should contain uppercase, lowercase letters, special characters and numbers.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}
