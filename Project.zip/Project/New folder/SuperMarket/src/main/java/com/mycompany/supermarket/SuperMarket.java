package com.mycompany.supermarket;

import java.io.*;
import java.util.ArrayList;

public class SuperMarket {

    public static void main(String[] args) throws Exception {
        ArrayList<Item> Item = new ArrayList<>();
        ArrayList<Customer> Customer = new ArrayList<>();
        ArrayList<Bill> Bill = new ArrayList<>();
        Bill b = new Bill(5, "Water", 29.95, 1);
        Bill.add(b);
        Employee e1 = new Employee(219939, "Reem", 30, "Manager");
        Employee e2 = new Employee(220091, "Omar", 19, "Employee");
        CustomerPlus cp = new CustomerPlus("Elite", "Ahmed", "Gamal", "ahmed@gmail.com", "FGed12@@", "gems");
        Customer c1 = new Customer("Maha", "Bahgat", "Maha@gmail.com", "Maha12!", "maha");
        Customer.add(c1);
        Customer c2 = new Customer("Shahd", "Amr");
        Customer.add(c2);
        e1.addItem(123, "Water", 3.99, 200, Item);
        e1.addItem(124, "Lays", 7.99, 188, Item);
        e1.addItem(125, "Milk", 34.49, 55, Item);
        e1.addItem(126, "Cadbury", 28.99, 50, Item);
        e1.addItem(127, "Pepsi", 7.99, 100, Item);
        e2.addItem(128, "KitKat", 22.49, 50, Item);
        e2.addItem(129, "Yogurt", 7.49, 75, Item);
        e2.addItem(130, "Nutella", 89.99, 30, Item);
        e2.addItem(131, "Tuna", 39.99, 42, Item);
        e2.addItem(132, "Corn Flakes", 32.99, 22, Item);

//        System.out.println(Bill);
//        System.out.println(Customer);
//        System.out.println(Item);
//        e1.removeItem(131,Item);
//        System.out.println(Item);
//        Customer.add(new Customer("Shady", "Anwar", "shady@hotmail.com","Tvfd2!", "S_Anwar"));
//        System.out.println(Customer);
//        
//        c1.makeAnOrder(Bill, Item);
//        c2.makeAnOrder(Bill, Item);
//        c2.cancelAnItem(Bill);
//        cp.makeAnOrder(Bill, Item);
//        cp.update_order(Bill, Item);
//        cp.viewBill(Bill);
//        c1.viewBill(Bill);
//        c2.viewBill(Bill);
//        c1.createAccount(Customer);
//        System.out.println(c1);
//        c1.manageAccount(Customer);
//        e1.updateItem(Item);
//        e1.generateReport(Bill);
//        
        FileOutputStream fos = new FileOutputStream("Customers.txt");
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(Customer);
        oos.close();
        fos.close();

        FileInputStream fis = new FileInputStream("Customers.txt");
        ObjectInputStream ois = new ObjectInputStream(fis);
        System.out.println(ois.readObject());
        ois.close();
        fis.close();

        FileOutputStream fos2 = new FileOutputStream("Items.txt");
        ObjectOutputStream oos2 = new ObjectOutputStream(fos2);
        oos2.writeObject(Item);
        oos2.close();
        fos2.close();

        FileInputStream fis2 = new FileInputStream("Items.txt");
        ObjectInputStream ois2 = new ObjectInputStream(fis2);
        System.out.println(ois2.readObject());
        ois2.close();
        fis2.close();

        FileOutputStream fos3 = new FileOutputStream("Bills.txt");
        ObjectOutputStream oos3 = new ObjectOutputStream(fos3);
        oos3.writeObject(Bill);
        oos3.close();
        fos3.close();

        FileInputStream fis3 = new FileInputStream("Bills.txt");
        ObjectInputStream ois3 = new ObjectInputStream(fis3);
        System.out.println(ois3.readObject());
        ois3.close();
        fis3.close();

        FileOutputStream fos4 = new FileOutputStream("CustomerPlus.txt");
        ObjectOutputStream oos4 = new ObjectOutputStream(fos4);
        oos4.writeObject(cp);
        oos4.close();
        fos4.close();

        FileInputStream fis4 = new FileInputStream("CustomerPlus.txt");
        ObjectInputStream ois4 = new ObjectInputStream(fis4);
        System.out.println((ArrayList<CustomerPlus>) ois4.readObject());
        fis4.close();
        ois4.close();

        }

}
