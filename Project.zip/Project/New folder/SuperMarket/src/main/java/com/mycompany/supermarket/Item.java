package com.mycompany.supermarket;

import java.io.Serializable;

public class Item implements Serializable{

    private int id;
    private String name;
    private double price;
    private int quantity;

    public Item() {
        id = 0;
        name = " ";
        price = 0.0;
        quantity = 0;
    }

    public Item(int i, String n, double p, int q) {
        id = i;
        name = n;
        price = p;
        quantity = q;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    @Override
    public String toString() {
        return "Item{" + "id=" + id + ", name=" + name + ", price=" + price + ", quantity=" + quantity + '}';
    }

}
