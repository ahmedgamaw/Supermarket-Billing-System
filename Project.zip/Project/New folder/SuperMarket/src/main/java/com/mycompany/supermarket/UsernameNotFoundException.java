/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.supermarket;

import javax.swing.JOptionPane;

/**
 *
 * @author HP
 */
public class UsernameNotFoundException extends Exception{
    UsernameNotFoundException(){
                            JOptionPane.showMessageDialog(null, "Invalid input, the username does not exist.", "Error", JOptionPane.ERROR_MESSAGE);

    }
}
