package com.mycompany.supermarket;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;
import javax.swing.*;

public class Customer implements Serializable {

    private String Fname;
    private String Lname;
    private String Email;
    private String password;
    private String username;

//    Scanner input = new Scanner(System.in);
    public Customer() {
        this.Fname = " ";
        this.Lname = " ";
        this.Email = " ";
        this.password = " ";
        this.username = " ";
    }

    public Customer(String Fname, String Lname) {
        this.Fname = Fname;
        this.Lname = Lname;
    }

    public Customer(String Fname, String Lname, String Email, String password, String username) {
        this.Fname = Fname;
        this.Lname = Lname;
        this.Email = Email;
        this.password = password;
        this.username = username;
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String Lname) {
        this.Lname = Lname;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void createAccount(ArrayList<Customer> Customer, String username, String pass, String email) {
        boolean name = false;
        do {
            for (int i = 0; i < Customer.size(); i++) {
                if (username.equals(Customer.get(i).getUsername())) {
                    name = true;
                    JOptionPane.showMessageDialog(null, "Username taken, please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } while (name == true);
        this.Email = email;
        this.password = pass;
    }

    public void manageAccount(ArrayList<Customer> Customer, int choice, String username, String input) {
        String x;
        {
            switch (choice) {
                case 1:
                    for (int i = 0; i < Customer.size(); i++) {
                        x = Customer.get(i).getUsername();
                        if (username.equals(x)) {
                            Customer.get(i).setUsername(input);
                            JOptionPane.showMessageDialog(null, "You have succesfully changed the username");
                            break;
                        }
                    }
                    break;

                case 2:
                    for (int i = 0; i < Customer.size(); i++) {
                        x = Customer.get(i).getUsername();
                        if (username.equals(x)) {
                            Customer.get(i).setEmail(input);
                            JOptionPane.showMessageDialog(null, "You have succesfully changed the email");
                        }
                    }
                    break;

                case 3:
                    for (int i = 0; i < Customer.size(); i++) {
                        x = Customer.get(i).getPassword();
                        if (username.equals(x)) {
                            Customer.get(i).setPassword(input);
                            JOptionPane.showMessageDialog(null, "You have succesfully changed the password");
                        }
                    }
                    break;
            }
        }
    }

    public int makeOrder(ArrayList<Bill> Bill, ArrayList<Item> Item, int selectedQan, int selected) {
        int qnt;
        double p;
        String n;
        Bill o = new Bill();
        Bill.add(o);

        for (int i = 0; i < Item.size(); i++) {
            for (int j = 0; j < Bill.size(); j++) {
                if (selected == Item.get(i).getId()) {
                    o.setAmount(selectedQan);
                    n = Item.get(i).getName();
                    o.setItemN(n);
                    p = Item.get(i).getPrice();
                    p *= selectedQan;
                    o.setnPrice(p);
                    qnt = Item.get(i).getQuantity();
                    qnt -= selectedQan;
                    Item.get(i).setQuantity(qnt);
                    o.setOrderNum(Bill.get(j).getoNum());
                    int y = o.getOrderNum();
                    return y;
                }
            }

        }
        return 0;
    }

    public void cancelAnItem(ArrayList<Bill> Bill, int id) {
        boolean y = false;
        for (int i = 0; i < Bill.size(); i++) {
            if (id == Bill.get(i).getOrderNum()) {
                Bill.remove(i);
                JOptionPane.showMessageDialog(null, "Item " + Bill.get(i).getOrderNum() + " has been removed");
                y = true;
                break;
            }
        }
        if (y == false) {
            JOptionPane.showMessageDialog(null, "Item does not exist", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void update_order(ArrayList<Bill> Bill, ArrayList<Item> Item, int newAmount, int order) {
        int oldAmount = 0, selected = 0, qnt, calc;
        double p;
        String selectedB;
        for (int i = 0; i < Bill.size(); i++) {
            if (order == Bill.get(i).getOrderNum()) {
                oldAmount = Bill.get(i).getAmount();
                selectedB = Bill.get(order).getItemN();
                if (selectedB.equals(Item.get(i).getName())) {
                    selected = Item.get(i).getId();
                }
                if (oldAmount < newAmount) {
                    for (int k = 0; k < Item.size(); k++) {
                        if (selected == Item.get(k).getId()) {
                            Bill.get(k).setAmount(newAmount);
                            p = Item.get(k).getPrice();
                            p *= newAmount;
                            Bill.get(k).setnPrice(p);
                            qnt = Item.get(k).getQuantity() + oldAmount;
                            qnt -= newAmount;
                            Item.get(k).setQuantity(qnt);
                            Bill.get(i).setAmount(newAmount);
                        }
                    }
                }
            } else if (oldAmount > newAmount) {
                calc = oldAmount - newAmount;
                for (int k = 0; k < Item.size(); k++) {
                    if (selected == Item.get(k).getId()) {
                        Item.get(k).setQuantity(calc);
                        Bill.get(i).setAmount(newAmount);
                    }
                }
            }
        }
    }

    public double viewBill(ArrayList<Bill> Bill, int orderNo) {
        double cost = 0;
        for (int i = 0; i < Bill.size(); i++) {
            if (orderNo == Bill.get(i).getOrderNum()) {
                cost += Bill.get(i).getnPrice();
            }
        }
        return cost;
    }

    public boolean login(ArrayList<Customer> Customer, String email, String password) {

        for (int i = 0; i < Customer.size(); i++) {
            if (email.equals(Customer.get(i).getEmail()) && password.equals(Customer.get(i).getPassword())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return "Customer{" + "Fname= " + Fname + ", Lname= " + Lname + ", Email= " + Email + ", password= " + password + ", username= " + username + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 41 * hash + Objects.hashCode(this.Email);
        hash = 41 * hash + Objects.hashCode(this.password);
        hash = 41 * hash + Objects.hashCode(this.username);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Customer other = (Customer) obj;
        if (!Objects.equals(this.Email, other.Email)) {
            return false;
        }
        if (!Objects.equals(this.password, other.password)) {
            return false;
        }
        return Objects.equals(this.username, other.username);
    }
}
